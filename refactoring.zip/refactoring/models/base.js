class Main {
    id = 0
    surname = "";
    name = '';
    max_id = 10000;

    constructor() {
        this.id = Math.floor(Math.random() * this.max_id);
    }

    getFullname () {
        return `${this.surname} ${name}`;
    }

}

module.exports = {
    Main,
};