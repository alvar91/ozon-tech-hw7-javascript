
const {Main} = require('./base.js');

class User extends Main {
    age = 0;
    position = '';
    manager = '';
    company = ''; // Больше не используем это поле
    experience = 0;


    setAge(age) {
        this.age = age;
    }

    positionSet(position) {
        this.position = position;
    }

    getFullname() {
        return `${this.surname} ${this.name}`;
    }

    SetObject(surname, name, age, position) {
        this.surname = surname;
        this.name = name;
        this.age = age;
        this.positionSet(position);

        if (this.age < 18) {
            this.experience = 0;
        } else if (this.age > 18) {
            this.experience = this.age - 18;
        } else if (this.age < 65) {
            this.experience = this.age - 18;
        }

        if (this.position == 'менеджер') {
            this.experience = this.experience * 3;
        }

        if (this.position == 'Тестировщик') {
            this.position = 'QA'
        }
    }

    setObjectWithCompany(surname, name, age, position, company) {
        this.surname = surname;
        this.name = name;
        this.age = age;
        this.positionSet(position);
        this.company = company;

        if (this.age < 18) {
            this.experience = 0;
        } else if (this.age > 18) {
            this.experience = this.age - 18;
        } else if (this.age < 65) {
            this.experience = this.age - 18;
        }

        if (this.position == 'менеджер') {
            this.experience = this.experience * 3;
        }

        if (this.company === 'Ozon') {
            this.company = 'Ozon Ltd';
        }

        if (this.position == 'Тестировщик') {
            this.position = 'QA'
        }
    }

    getExp() {
        // ВАЖНО!!!!! Не забывать раскомментировать!!!!!!!! ВАЖНО!!!!!
        // this.experience = this.experienceSwitch(this.experience);
        return this.experience;
    }

    // ВАЖНО!!!!! Не забывать раскомментировать!!!!!!!! ВАЖНО!!!!!
//    experienceSwitch(Number) {
//        function isPrime(m) {
//            var i;
//            for (i = 2; i < m; i++) {
//                if (m % i === 0) {
//                    return false;
//                }
//            }
//            return true;
//        }
//
//        // переменная для цикла
//        var j;
//        var sequence = [];
//        for (j = 2; j < InputNumber; j++) {
//            if (InputNumber % j === 0 && isPrime(j)) {
//                sequence.push(j);
//            }
//        }
//        return sequence;
//    };

}

module.exports = {
    User,
};
