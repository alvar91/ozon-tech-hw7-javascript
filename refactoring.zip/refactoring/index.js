const {User} = require('./models/user');

// Создаем первого пользователя
let user = new User();
user.SetObject('Агальцов', 'Антон', 50, 'менеджер');
user.setAge(60);
printUser(user)

// Создаем второго пользователя
var user2 = generateUser('Сухарев', 'Иван', 'Frontend');
printUser(user2);

// Еще
var user2 = generateUser('Кирилл', 'Иващенко', 'Backend');
printUser(user2);

function upperName(str) {
    return str.toUpperCase();
}

// Еще
var a = generateUser('Трещенко', 'Диана', 'Тестировщик');
printUser(a);

// Финал
var man = generateUser('Трещенко', 'Светлана', 'менеджер');
printUser(man);

// Вспомогательные функции

function generateUser(surname, name, position) {
    const user = new User();
    user.setObjectWithCompany(upperName(surname), upperName(name), Math.floor(Math.random() * 70), position, 'Ozon');
    return user;
}

function printUser(user) {
    if (user.position === 'менеджер') {
        console.log('\x1b[36m%s\x1b[0m', `${user.id} - ${user.getFullname()} | опыт: ${user.age} | возраст: ${user.getExp()}`)
    } else {
        console.log(`${user.id} - ${user.getFullname()} | опыт: ${user.age} | возраст: ${user.getExp()}`)
    }
}
